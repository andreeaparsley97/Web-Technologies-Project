import React from 'react';
import LoginForm from "./loginform";

export const LogDiscography = () => {
    return (
        <div>
            <h1>Admin Login</h1>
            <LoginForm/>
        </div>);
};